
----------------------------------------------------------------------------------
NOTE:	It is highly recommended to first go through the Manuals on the Vital 
	System Website especially before wiring!
		
LINK:	www.vitalsystem.com/

----------------------------------------------------------------------------------


Mach4 Plugin Setup

* Make sure Mach4 is NOT running.
* Copy the "M4HiCON.m4pw" and "M4HiCON.sig" files to the plugins folder of your Mach4 install directory (EX. C:\Mach4\Plugins)
* NOTE: Check Axis output settings in Mach4 plugin config screen.


The current firmware version on your device may not be the latest. To ensure plugin compatibility, you may need to update the firmware as necessary.This can be done through the VSI Device Manager application.


Firmware Upgrade

* New firmware version can be programmed using the VSI Device 
  Manager application available from the Vital System Inc. website.

* VSI DeviceManager Download Link
  < www.vitalsystem.com/portal/motion/VSI_Device_Manager.zip >

* VSI DeviceManager Manual Download Link
  < www.vitalsystem.com/portal/motion/VSI_Device_Manager_Manual.pdf >


